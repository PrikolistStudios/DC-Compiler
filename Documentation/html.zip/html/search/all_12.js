var searchData=
[
  ['var_0',['Var',['../struct_var.html',1,'']]],
  ['var_1',['var',['../class_poliz_var.html#a7960279607c29dd39feb4d4ffc086511',1,'PolizVar']]],
  ['var_2',['Var',['../struct_var.html#a553613287f180968f301545fe23c107f',1,'Var::Var(VarTypes type, int size=0)'],['../struct_var.html#a3dec6b7eb4a17e2f5edb5e97ec658c9c',1,'Var::Var()']]],
  ['var_5f_3',['var_',['../class_poliz_var.html#a9b0891bfaf9b8184221443e87079973e',1,'PolizVar::var_()'],['../class_t_i_d_row.html#a8a0fa72a0d949f19accbb230ad7e663d',1,'TIDRow::var_()']]],
  ['vardata_4',['VarData',['../struct_var_data.html',1,'VarData'],['../struct_var_data.html#ac323fa5bd3b6dda0789ad448532f9ebf',1,'VarData::VarData(VarTypes type)'],['../struct_var_data.html#af1ad21b6a1546c73ba9413085498b719',1,'VarData::VarData(int val)'],['../struct_var_data.html#ae5241e856b1ecdb1ec09f0857f7bbfe1',1,'VarData::VarData(char val)'],['../struct_var_data.html#a048d28fa84972db618604d25d73c4c89',1,'VarData::VarData(float val)'],['../struct_var_data.html#ad03e89e0f6ed06130078f4f943a2ee96',1,'VarData::VarData(bool val)'],['../struct_var_data.html#a9b65bdca6969bfb0c15c4cc6e5359655',1,'VarData::VarData(std::string val)']]],
  ['variable_5',['Variable',['../_poliz_8h.html#a7374e8d96fbb24ac365642f83240cd8ea18c03e9114911894d062ca85749aeed9',1,'Poliz.h']]],
  ['variables_5f_6',['variables_',['../class_struct_info.html#a506320a64578a7a9b694466adf3c805f',1,'StructInfo']]],
  ['vartypes_7',['VarTypes',['../_poliz_8h.html#a403e52e933033645c3388146d5e2edd2',1,'Poliz.h']]]
];
