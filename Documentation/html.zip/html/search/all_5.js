var searchData=
[
  ['getid_0',['GetID',['../class_t_i_d_tree.html#a0b9c3c6e1ff6a180e4df00c1fdd8a16f',1,'TIDTree']]],
  ['gettype_1',['getType',['../class_separator.html#a588ac7c19bfd2f22ced1cfabcf3d98b3',1,'Separator']]]
];
