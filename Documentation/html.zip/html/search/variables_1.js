var searchData=
[
  ['bool_5f_0',['bool_',['../struct_var_data.html#a7c1100b169d748bd5d457727f9994e97',1,'VarData']]]
];
