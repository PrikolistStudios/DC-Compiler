var searchData=
[
  ['oper_0',['Oper',['../_poliz_8h.html#a7374e8d96fbb24ac365642f83240cd8ea1b9f0be9e31ba4bfec91f6390d2681c4',1,'Poliz.h']]]
];
