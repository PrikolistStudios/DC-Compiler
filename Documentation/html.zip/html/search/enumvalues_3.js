var searchData=
[
  ['float_0',['Float',['../_poliz_8h.html#a403e52e933033645c3388146d5e2edd2ad67b0ee7230dcecb610254e4e5e589cd',1,'Poliz.h']]],
  ['func_1',['Func',['../_poliz_8h.html#a7374e8d96fbb24ac365642f83240cd8eadb161d6438c5192315b3d481a1d28005',1,'Poliz.h']]]
];
