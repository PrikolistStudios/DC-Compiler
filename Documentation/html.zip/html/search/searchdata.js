var indexSectionsWithContent =
{
  0: "abcdfgiklmnopqrstuvw~",
  1: "cfilpstv",
  2: "cilpst",
  3: "abcfgilnoprstuvw~",
  4: "abcdfilmnoprstv",
  5: "lpv",
  6: "abcfiklnopqrstv",
  7: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "related"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные",
  5: "Перечисления",
  6: "Элементы перечислений",
  7: "Друзья"
};

