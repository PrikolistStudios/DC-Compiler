var searchData=
[
  ['variable_0',['Variable',['../_poliz_8h.html#a7374e8d96fbb24ac365642f83240cd8ea18c03e9114911894d062ca85749aeed9',1,'Poliz.h']]]
];
