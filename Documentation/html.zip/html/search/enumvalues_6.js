var searchData=
[
  ['lit_0',['Lit',['../_poliz_8h.html#a7374e8d96fbb24ac365642f83240cd8ea55aede54bfa7ba3edd1add23adb73c60',1,'Poliz.h']]]
];
