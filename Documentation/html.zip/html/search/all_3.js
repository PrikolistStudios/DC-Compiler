var searchData=
[
  ['data_5f_0',['data_',['../class_poliz_lit.html#aaf73316aab962e1424bc3d9fcc61dc24',1,'PolizLit::data_()'],['../struct_var.html#af16ff5fbe5da44fb72915d0602d0b265',1,'Var::data_()']]]
];
