var searchData=
[
  ['stack_5f_0',['stack_',['../class_compiler.html#a31a2d50c82bc6b20120178cab7046aa5',1,'Compiler::stack_()'],['../class_type_stack.html#a97d1379aec042f08c68df7bd2ae9cb9a',1,'TypeStack::stack_()']]],
  ['string_5f_1',['string_',['../struct_var_data.html#a6b2b6a5480fc3ded4ab4a7aff31ee2be',1,'VarData']]],
  ['structs_5f_2',['structs_',['../class_compiler.html#a7f1505a9eb1f1397ff4262f31498cf72',1,'Compiler']]]
];
