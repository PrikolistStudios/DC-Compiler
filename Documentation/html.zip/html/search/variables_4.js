var searchData=
[
  ['float_5f_0',['float_',['../struct_var_data.html#a5feae31d4940c5a5d58d2b29fffafcc8',1,'VarData']]],
  ['func_5fname_5f_1',['func_name_',['../class_call_stack_elem.html#a51511add926cc5ec262a390f6608e364',1,'CallStackElem::func_name_()'],['../class_poliz_func_call.html#adb0e9d01b6f94232dcfa39796e8bcf0b',1,'PolizFuncCall::func_name_()']]],
  ['funcs_5f_2',['funcs_',['../class_compiler.html#adcda90ac8c151ae9805ecd79dc43fd60',1,'Compiler::funcs_()'],['../class_interpreter.html#a4586350d740d97c64db31d46c0ff80be',1,'Interpreter::funcs_()']]]
];
