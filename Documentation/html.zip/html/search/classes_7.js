var searchData=
[
  ['var_0',['Var',['../struct_var.html',1,'']]],
  ['vardata_1',['VarData',['../struct_var_data.html',1,'']]]
];
