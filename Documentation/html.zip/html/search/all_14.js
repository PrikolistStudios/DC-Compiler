var searchData=
[
  ['_7epolizelem_0',['~PolizElem',['../class_poliz_elem.html#ae2e5b4a1786727232a2d753239401063',1,'PolizElem']]]
];
