var searchData=
[
  ['polizelemtypes_0',['PolizElemTypes',['../_poliz_8h.html#a7374e8d96fbb24ac365642f83240cd8e',1,'Poliz.h']]]
];
