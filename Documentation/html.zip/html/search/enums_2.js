var searchData=
[
  ['vartypes_0',['VarTypes',['../_poliz_8h.html#a403e52e933033645c3388146d5e2edd2',1,'Poliz.h']]]
];
