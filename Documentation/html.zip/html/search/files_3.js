var searchData=
[
  ['poliz_2eh_0',['Poliz.h',['../_poliz_8h.html',1,'']]]
];
