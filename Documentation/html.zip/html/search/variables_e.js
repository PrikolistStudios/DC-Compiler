var searchData=
[
  ['var_5f_0',['var_',['../class_poliz_var.html#a9b0891bfaf9b8184221443e87079973e',1,'PolizVar::var_()'],['../class_t_i_d_row.html#a8a0fa72a0d949f19accbb230ad7e663d',1,'TIDRow::var_()']]],
  ['variables_5f_1',['variables_',['../class_struct_info.html#a506320a64578a7a9b694466adf3c805f',1,'StructInfo']]]
];
