var searchData=
[
  ['address_0',['Address',['../_poliz_8h.html#a7374e8d96fbb24ac365642f83240cd8ea43f2a8aab5cba317e9ad9fe8589df00a',1,'Poliz.h']]]
];
